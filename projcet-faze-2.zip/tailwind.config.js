module.exports = {
    darkMode: 'class',
  }